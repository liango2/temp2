(function () {
  'use strict';

  (async () => {
    await import(
      /* @vite-ignore */
      chrome.runtime.getURL("assets/index.tsx-c06d502d.js")
    );
  })().catch(console.error);

})();
